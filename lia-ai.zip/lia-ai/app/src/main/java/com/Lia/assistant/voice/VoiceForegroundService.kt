package com.Lia.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.Lia.assistant.MainActivity
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.AssistantBrand

class VoiceForegroundService : Service() {

    companion object {
        const val ACTION_STOP = "com.Lia.assistant.STOP_VOICE"
        private const val CHANNEL_ID = "lia_voice"
        private const val NOTIF_ID = 1001

        fun startIntent(ctx: Context) = Intent(ctx, VoiceForegroundService::class.java)
        fun stopIntent(ctx: Context) =
            Intent(ctx, VoiceForegroundService::class.java).setAction(ACTION_STOP)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            VoiceSessionManager.stop()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        VoiceSessionManager.start(applicationContext)
        return START_STICKY
    }

    private fun assistantName(): String =
        NovaPreferences.getString(this, NovaPreferences.Keys.ASSISTANT_NAME, AssistantBrand.NAME)
            .ifBlank { AssistantBrand.NAME }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val name = assistantName()
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "$name voice session", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(this, 1, stopIntent(this), flags)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("$name is listening")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        VoiceSessionManager.stop()
        super.onDestroy()
    }
}
