package com.Lia.assistant.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun LiaApp() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        containerColor = LiaColors.Night,
        bottomBar = {
            NavigationBar(containerColor = LiaColors.Surface) {
                val colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = LiaColors.OnAccent,
                    indicatorColor = LiaColors.Accent,
                    unselectedIconColor = LiaColors.TextSecondary,
                    selectedTextColor = LiaColors.Accent,
                    unselectedTextColor = LiaColors.TextSecondary,
                )
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Mic, null) }, label = { Text("Voice") }, colors = colors)
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Chat, null) }, label = { Text("Chat") }, colors = colors)
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Settings") }, colors = colors)
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> VoiceScreen()
                1 -> ChatScreen()
                else -> SettingsScreen()
            }
        }
    }
}
