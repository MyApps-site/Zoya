package com.Lia.assistant.voice

import android.content.Context
import com.Lia.assistant.action.ActionExecutor
import com.Lia.assistant.action.InstalledAppLabelCache
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.PersonalityRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

enum class NovaOrbState { IDLE, LISTENING, THINKING, SPEAKING, CONNECTING, ERROR }

/** One voice session for the whole process, independent of any screen. */
object VoiceSessionManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sessionMutex = Mutex()
    private val reconnectMutex = Mutex()

    private val _state = MutableStateFlow(NovaOrbState.IDLE)
    val state: StateFlow<NovaOrbState> = _state.asStateFlow()
    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()
    private val _statusText = MutableStateFlow("Tap start to talk")
    val statusText: StateFlow<String> = _statusText.asStateFlow()
    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()
    private val _detectedLanguage = MutableStateFlow(DetectedLanguage.UNKNOWN)
    val detectedLanguage: StateFlow<DetectedLanguage> = _detectedLanguage.asStateFlow()
    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()

    private val memory = ConversationMemory()
    private var appContext: Context? = null
    private var client: GeminiLiveClient? = null
    private var audio: LiveAudioIO? = null
    private var micStarted = false
    @Volatile private var sessionEpoch = 0
    private var reconnectJob: Job? = null
    private var reconnectCount = 0
    private var silenceJob: Job? = null
    private var speaking = false
    private var assistantLine = StringBuilder()

    fun start(ctx: Context) {
        if (_isActive.value) return
        val app = ctx.applicationContext
        appContext = app
        if (!ApiKeyStore.hasKey(app)) {
            _state.value = NovaOrbState.ERROR
            _statusText.value = "Add your Gemini key in Settings first"
            _lastError.value = "No API key"
            return
        }
        _isActive.value = true
        _lastError.value = null
        _state.value = NovaOrbState.CONNECTING
        _statusText.value = "Connecting…"
        _transcript.value = ""
        memory.clear()
        reconnectCount = 0
        micStarted = false
        EchoGuard.reset()
        InstalledAppLabelCache.prewarm(app)
        audio = LiveAudioIO(
            onMicChunk = { bytes ->
                if (!_muted.value && !EchoGuard.isMicMuted()) client?.sendAudio(bytes)
            },
            onMicAmplitude = { rms ->
                if (_state.value == NovaOrbState.LISTENING) _amplitude.value = rms
            },
        ).also { it.setVolume(NovaPreferences.getFloat(app, NovaPreferences.Keys.VOICE_VOLUME, 1f)) }
        scope.launch { sessionMutex.withLock { connectSession(isResuming = false) } }
    }

    private suspend fun connectSession(isResuming: Boolean) {
        val app = appContext ?: return
        val epoch = ++sessionEpoch
        client?.disconnect()
        val personality = PersonalityRepository.getPersonality(app)
        val language = PersonalityRepository.getLanguage(app)
        val name = PersonalityRepository.getAssistantName(app)
        val voice = mapVoice(PersonalityRepository.getVoiceName(app))
        val prompt = PersonalityPromptBuilder.build(
            personality, language, _detectedLanguage.value,
            if (isResuming) memory.recap() else null, name
        )
        val c = GeminiLiveClient(ApiKeyStore.getKey(app))
        client = c
        c.connect(prompt, voice, object : GeminiLiveClient.Listener {
            private fun current() = epoch == sessionEpoch && _isActive.value

            override fun onSetupComplete() {
                if (!current()) return
                reconnectCount = 0
                _lastError.value = null
                _state.value = NovaOrbState.LISTENING
                _statusText.value = "Listening…"
                if (!micStarted) {
                    try {
                        audio?.startMic()
                        micStarted = true
                    } catch (e: Exception) {
                        fail("Microphone could not start")
                    }
                }
            }

            override fun onAudioChunk(bytes: ByteArray) {
                if (!current()) return
                val a = audio ?: return
                if (!speaking) {
                    speaking = true
                    EchoGuard.notifyPlaybackStarted()
                }
                val amp = a.playChunk(bytes)
                _state.value = NovaOrbState.SPEAKING
                _statusText.value = "Speaking…"
                _amplitude.value = amp
                silenceJob?.cancel()
                silenceJob = scope.launch {
                    delay(300)
                    if (current()) endSpeaking()
                }
            }

            override fun onInputTranscript(text: String) {
                if (!current()) return
                memory.add(ConversationMemory.Role.USER, text)
                val d = LanguageDetector.detect(text)
                if (d != DetectedLanguage.UNKNOWN) _detectedLanguage.value = d
                _transcript.value = text
                if (_state.value != NovaOrbState.SPEAKING) _state.value = NovaOrbState.THINKING
            }

            override fun onOutputTranscript(text: String) {
                if (!current()) return
                assistantLine.append(text)
            }

            override fun onToolCall(id: String, name: String, args: JSONObject) {
                if (!current()) return
                scope.launch {
                    val result = try {
                        ActionExecutor.execute(app, name, args)
                    } catch (e: Exception) {
                        JSONObject().put("error", "action_failed")
                    }
                    if (epoch == sessionEpoch) c.sendToolResponse(id, name, result)
                }
            }

            override fun onTurnComplete() {
                if (!current()) return
                flushAssistantLine()
                endSpeaking()
            }

            override fun onInterrupted() {
                if (!current()) return
                audio?.flushPlayback()
                flushAssistantLine()
                endSpeaking()
            }

            override fun onError(message: String) {
                if (epoch != sessionEpoch || !_isActive.value) return
                _lastError.value = message
                scheduleReconnect()
            }

            override fun onClosed() {
                if (epoch != sessionEpoch || !_isActive.value) return
                scheduleReconnect()
            }
        })
    }

    private fun flushAssistantLine() {
        if (assistantLine.isNotEmpty()) {
            memory.add(ConversationMemory.Role.ASSISTANT, assistantLine.toString())
            assistantLine = StringBuilder()
        }
    }

    private fun endSpeaking() {
        silenceJob?.cancel()
        if (speaking) {
            speaking = false
            EchoGuard.notifyPlaybackStopped()
        }
        if (_isActive.value && _state.value != NovaOrbState.ERROR && _state.value != NovaOrbState.CONNECTING) {
            _state.value = NovaOrbState.LISTENING
            _statusText.value = "Listening…"
            _amplitude.value = 0f
        }
    }

    private fun fail(msg: String) {
        _lastError.value = msg
        _state.value = NovaOrbState.ERROR
        _statusText.value = msg
    }

    private fun scheduleReconnect() {
        if (reconnectJob?.isActive == true) return
        reconnectJob = scope.launch {
            reconnectMutex.withLock {
                if (!_isActive.value) return@withLock
                if (reconnectCount >= 5) {
                    fail("Connection lost - tap Stop and reopen Voice Mode")
                    return@withLock
                }
                reconnectCount++
                _state.value = NovaOrbState.CONNECTING
                _statusText.value = "Reconnecting…"
                delay(1200)
                if (!_isActive.value) return@withLock
                sessionMutex.withLock { connectSession(isResuming = true) }
            }
        }
    }

    /** Live cannot change the system instruction mid-session, so reconnect with a recap. */
    fun refreshInstructions(ctx: Context) {
        if (!_isActive.value) return
        appContext = ctx.applicationContext
        scheduleReconnect()
    }

    fun toggleMute() {
        _muted.value = !_muted.value
    }

    fun stop() {
        reconnectJob?.cancel()
        silenceJob?.cancel()
        sessionEpoch++
        _isActive.value = false
        client?.disconnect()
        client = null
        audio?.release()
        audio = null
        micStarted = false
        speaking = false
        EchoGuard.reset()
        memory.clear()
        assistantLine = StringBuilder()
        _muted.value = false
        _amplitude.value = 0f
        _state.value = NovaOrbState.IDLE
        _statusText.value = "Tap start to talk"
    }

    private fun mapVoice(ui: String): String = when (ui.lowercase()) {
        "aoede", "puck", "charon", "kore", "fenrir", "leda", "orus", "zephyr" ->
            ui.replaceFirstChar { it.uppercase() }
        else -> "Aoede"
    }
}
