package com.Lia.assistant.voice

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * While Lia is speaking the mic is muted, so she does not hear herself on the loudspeaker.
 * After playback stops the mic stays muted for a short tail so the echo dies out.
 */
object EchoGuard {
    const val ECHO_TAIL_MS = 450L
    const val WATCHDOG_MS = 60_000L

    @Volatile var scope: CoroutineScope = CoroutineScope(Dispatchers.Default)

    private val lock = Any()
    private var active = 0
    @Volatile private var muted = false
    private var tailJob: Job? = null
    private var watchdogJob: Job? = null

    fun notifyPlaybackStarted() {
        synchronized(lock) {
            active++
            muted = true
            tailJob?.cancel()
            tailJob = null
            watchdogJob?.cancel()
            watchdogJob = scope.launch {
                delay(WATCHDOG_MS)
                synchronized(lock) { active = 0; muted = false }
            }
        }
    }

    fun notifyPlaybackStopped() {
        synchronized(lock) {
            if (active > 0) active--
            if (active == 0) {
                watchdogJob?.cancel()
                watchdogJob = null
                tailJob?.cancel()
                tailJob = scope.launch {
                    delay(ECHO_TAIL_MS)
                    synchronized(lock) { if (active == 0) muted = false }
                }
            }
        }
    }

    fun isMicMuted(): Boolean = muted

    fun reset() {
        synchronized(lock) {
            active = 0
            muted = false
            tailJob?.cancel(); tailJob = null
            watchdogJob?.cancel(); watchdogJob = null
        }
    }
}
