package com.Lia.assistant.voice

import com.Lia.assistant.action.LiaCapabilityPrompts
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality

enum class DetectedLanguage { HINDI, HINGLISH, ENGLISH, UNKNOWN }

object LanguageDetector {
    private val markers = setOf(
        "hai", "hain", "ho", "kya", "kyun", "kaise", "nahi", "haan", "mujhe", "tumhe", "aap", "mera",
        "yaar", "bhai", "accha", "theek", "matlab", "karna", "karo", "raha", "chahiye", "batao",
        "suno", "dekho", "abhi", "phir", "lekin", "bahut", "thoda", "kuch", "sab", "wala", "wali",
        "kar", "mein", "me", "ko", "ka", "ki", "ke", "tum", "hum", "kaun", "kahan", "kab"
    )

    fun detect(text: String): DetectedLanguage {
        if (text.isBlank()) return DetectedLanguage.UNKNOWN
        if (text.any { it.code in 0x0900..0x097F }) return DetectedLanguage.HINDI
        val words = text.lowercase().split(Regex("[^a-zA-Z']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return DetectedLanguage.UNKNOWN
        val hits = words.count { it in markers }
        return if (words.size <= 4) {
            if (hits >= 1) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        } else {
            val ratio = hits.toDouble() / words.size
            if (hits >= 2 || ratio >= 0.15) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        }
    }
}

/** Rolling in-memory window of the last 12 turns. Cleared when the session stops. */
class ConversationMemory(private val maxTurns: Int = 12) {
    enum class Role { USER, ASSISTANT }
    data class Turn(val role: Role, val text: String)

    private val turns = ArrayDeque<Turn>()

    @Synchronized
    fun add(role: Role, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        turns.addLast(Turn(role, t))
        while (turns.size > maxTurns) turns.removeFirst()
    }

    @Synchronized
    fun recap(): String? {
        if (turns.isEmpty()) return null
        val s = turns.joinToString("\n") { (if (it.role == Role.USER) "User: " else "You: ") + it.text }
        return if (s.length > 1600) s.takeLast(1600) else s
    }

    @Synchronized
    fun clear() = turns.clear()
}

object PersonalityPromptBuilder {
    fun build(
        personality: Personality,
        language: LanguagePreference,
        detected: DetectedLanguage,
        recap: String?,
        assistantName: String,
    ): String {
        val base = "You are $assistantName, a persistent personal voice assistant living on the user's phone. " +
            "Keep replies short and conversational, like spoken conversation."
        val languagePolicy = when (language) {
            LanguagePreference.AUTO ->
                "Language: match the user's language turn by turn (Hindi, Hinglish or English) and never translate what they said." +
                    when (detected) {
                        DetectedLanguage.HINDI -> " The user most recently spoke Hindi."
                        DetectedLanguage.HINGLISH -> " The user most recently spoke Hinglish."
                        DetectedLanguage.ENGLISH -> " The user most recently spoke English."
                        DetectedLanguage.UNKNOWN -> ""
                    }
            LanguagePreference.HINDI -> "Language: always reply in Hindi, written and spoken naturally."
            LanguagePreference.HINGLISH -> "Language: always reply in Hinglish, the way people casually talk in India."
            LanguagePreference.ENGLISH -> "Language: always reply in English."
        }
        val safety = "Safety: never claim to be human. No explicit content. Stop a topic when asked. Vary your phrasing."
        val parts = mutableListOf(
            base,
            LiaCapabilityPrompts.toolInstruction(assistantName),
            personality.systemInstruction,
            languagePolicy,
            safety,
        )
        if (recap != null) {
            parts += "This is a continuing conversation — do not greet again. Recap:\n$recap"
        }
        return parts.joinToString("\n\n")
    }
}
