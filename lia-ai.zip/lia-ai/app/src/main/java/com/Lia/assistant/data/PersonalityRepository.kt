package com.Lia.assistant.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.assistantStore: DataStore<Preferences> by preferencesDataStore("assistant_settings")

object PersonalityRepository {
    private val PERSONALITY = stringPreferencesKey("personality")
    private val LANGUAGE = stringPreferencesKey("language")
    private val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
    private val VOICE_NAME = stringPreferencesKey("voice_name")

    fun personality(ctx: Context): Flow<Personality> = ctx.applicationContext.assistantStore.data.map {
        Personality.fromName(
            it[PERSONALITY] ?: NovaPreferences.getString(ctx, NovaPreferences.Keys.PERSONALITY, Personality.NORMAL.name)
        )
    }

    fun language(ctx: Context): Flow<LanguagePreference> = ctx.applicationContext.assistantStore.data.map {
        LanguagePreference.fromName(
            it[LANGUAGE] ?: NovaPreferences.getString(ctx, NovaPreferences.Keys.LANGUAGE, LanguagePreference.AUTO.name)
        )
    }

    fun assistantName(ctx: Context): Flow<String> = ctx.applicationContext.assistantStore.data.map {
        (it[ASSISTANT_NAME] ?: NovaPreferences.getString(ctx, NovaPreferences.Keys.ASSISTANT_NAME, AssistantBrand.NAME))
            .ifBlank { AssistantBrand.NAME }
    }

    fun voiceName(ctx: Context): Flow<String> = ctx.applicationContext.assistantStore.data.map {
        (it[VOICE_NAME] ?: NovaPreferences.getString(ctx, NovaPreferences.Keys.VOICE_NAME, "Aoede"))
            .ifBlank { "Aoede" }
    }

    suspend fun getPersonality(ctx: Context): Personality = personality(ctx).first()
    suspend fun getLanguage(ctx: Context): LanguagePreference = language(ctx).first()
    suspend fun getAssistantName(ctx: Context): String = assistantName(ctx).first()
    suspend fun getVoiceName(ctx: Context): String = voiceName(ctx).first()

    suspend fun setPersonality(ctx: Context, value: Personality) {
        ctx.applicationContext.assistantStore.edit { it[PERSONALITY] = value.name }
        NovaPreferences.putString(ctx, NovaPreferences.Keys.PERSONALITY, value.name)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setLanguage(ctx: Context, value: LanguagePreference) {
        ctx.applicationContext.assistantStore.edit { it[LANGUAGE] = value.name }
        NovaPreferences.putString(ctx, NovaPreferences.Keys.LANGUAGE, value.name)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setAssistantName(ctx: Context, value: String) {
        val clean = value.trim().ifBlank { AssistantBrand.NAME }
        ctx.applicationContext.assistantStore.edit { it[ASSISTANT_NAME] = clean }
        NovaPreferences.putString(ctx, NovaPreferences.Keys.ASSISTANT_NAME, clean)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setVoiceName(ctx: Context, value: String) {
        ctx.applicationContext.assistantStore.edit { it[VOICE_NAME] = value }
        NovaPreferences.putString(ctx, NovaPreferences.Keys.VOICE_NAME, value)
        VoiceSessionManager.refreshInstructions(ctx)
    }
}
