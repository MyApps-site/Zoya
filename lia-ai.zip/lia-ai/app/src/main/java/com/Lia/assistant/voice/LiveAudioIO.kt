package com.Lia.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.sqrt

class LiveAudioIO(
    private val onMicChunk: (ByteArray) -> Unit,
    private val onMicAmplitude: (Float) -> Unit,
) {
    companion object {
        const val MIC_RATE = 16000
        const val SPEAKER_RATE = 24000

        /** Little-endian PCM16 -> 0..1 */
        fun rms(bytes: ByteArray, length: Int = bytes.size): Float {
            val n = length / 2
            if (n == 0) return 0f
            var sum = 0.0
            var i = 0
            while (i + 1 < length) {
                val s = ((bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)).toShort().toInt()
                sum += s.toDouble() * s
                i += 2
            }
            return (sqrt(sum / n) / 32768.0).toFloat().coerceIn(0f, 1f)
        }
    }

    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var volume = 1f
    private val effects = mutableListOf<android.media.audiofx.AudioEffect>()

    @SuppressLint("MissingPermission")
    @Synchronized
    fun startMic() {
        if (micRunning) return
        val minBuf = AudioRecord.getMinBufferSize(MIC_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, MIC_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 4096)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("Microphone could not start")
        }
        val sid = rec.audioSessionId
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.also { it.enabled = true; effects += it } } catch (_: Exception) {}
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.also { it.enabled = true; effects += it } } catch (_: Exception) {}
        try { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.also { it.enabled = true; effects += it } } catch (_: Exception) {}
        record = rec
        micRunning = true
        rec.startRecording()
        micThread = Thread({
            val buf = ByteArray(2048)
            while (micRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    val chunk = buf.copyOf(n)
                    onMicAmplitude(rms(chunk, n))
                    onMicChunk(chunk)
                } else if (n < 0) break
            }
        }, "lia-mic").also { it.start() }
    }

    @Synchronized
    fun stopMic() {
        micRunning = false
        try { micThread?.join(300) } catch (_: Exception) {}
        micThread = null
        effects.forEach { try { it.release() } catch (_: Exception) {} }
        effects.clear()
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        record = null
    }

    @Synchronized
    private fun ensureTrack(): AudioTrack {
        track?.let { return it }
        val minBuf = AudioTrack.getMinBufferSize(SPEAKER_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SPEAKER_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.setVolume(volume)
        t.play()
        track = t
        return t
    }

    /** Writes the chunk and returns its RMS (for the UI). */
    fun playChunk(bytes: ByteArray): Float {
        val t = ensureTrack()
        t.write(bytes, 0, bytes.size)
        return rms(bytes)
    }

    @Synchronized
    fun flushPlayback() {
        val t = track ?: return
        try { t.pause(); t.flush(); t.play() } catch (_: Exception) {}
    }

    @Synchronized
    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        try { track?.setVolume(volume) } catch (_: Exception) {}
    }

    @Synchronized
    fun release() {
        stopMic()
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }
}
