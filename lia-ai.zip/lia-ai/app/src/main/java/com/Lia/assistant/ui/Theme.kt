package com.Lia.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// "A pearl of light in the night": deep indigo with one marigold accent.
object LiaColors {
    val Night = Color(0xFF06050E)
    val Surface = Color(0xFF17143A)
    val Raised = Color(0xFF221E4D)
    val Accent = Color(0xFFFFB547)
    val OnAccent = Color(0xFF1B1304)
    val Text = Color(0xFFEEE9FF)
    val TextSecondary = Color(0xFFA7A0CC)
    val Lagoon = Color(0xFF3FE0D0)
    val Lotus = Color(0xFFFF6FAE)
    val Error = Color(0xFFFF7A85)
}

@Composable
fun LiaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = LiaColors.Accent,
            onPrimary = LiaColors.OnAccent,
            background = LiaColors.Night,
            onBackground = LiaColors.Text,
            surface = LiaColors.Surface,
            onSurface = LiaColors.Text,
            surfaceVariant = LiaColors.Raised,
            onSurfaceVariant = LiaColors.TextSecondary,
            error = LiaColors.Error,
        ),
        content = content,
    )
}
