package com.Lia.assistant.voice

import android.util.Log
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatTurn(val isUser: Boolean, val text: String)

sealed class ChatReplyResult {
    data class Success(val text: String) : ChatReplyResult()
    data class Error(val message: String) : ChatReplyResult()
}

object GeminiTextClient {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val TAG = "GeminiText"

    internal val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    @Volatile private var cachedModel: String? = null

    /** Picks a current flash model from ListModels so a Google rename does not break the app. */
    internal suspend fun resolveModel(apiKey: String): String? {
        cachedModel?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder().url("$BASE/models?key=$apiKey").build()
                http.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext null
                    val models = JSONObject(resp.body?.string().orEmpty()).optJSONArray("models") ?: return@withContext null
                    var fallback: String? = null
                    for (i in 0 until models.length()) {
                        val m = models.getJSONObject(i)
                        val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                        var ok = false
                        for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
                        if (!ok) continue
                        val name = m.optString("name")
                        if (fallback == null) fallback = name
                        val n = name.lowercase()
                        if ("flash" in n && "live" !in n && "image" !in n && "tts" !in n) {
                            cachedModel = name
                            return@withContext name
                        }
                    }
                    cachedModel = fallback
                    fallback
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    suspend fun reply(apiKey: String, systemInstruction: String, history: List<ChatTurn>): ChatReplyResult {
        if (apiKey.isBlank()) return ChatReplyResult.Error("Add your Gemini key in Settings first.")
        if (history.isEmpty()) return ChatReplyResult.Error("Nothing to answer yet.")
        val model = resolveModel(apiKey)
            ?: return ChatReplyResult.Error("Couldn't reach Gemini. Check your internet and your key.")

        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject()
                    .put("role", if (it.isUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
            .put("contents", contents)

        return withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder()
                    .url("$BASE/$model:generateContent")
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val reason = try {
                            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
                        } catch (_: Exception) { "" }
                        Log.w(TAG, "HTTP ${resp.code}: ${reason.take(120)}")
                        return@use ChatReplyResult.Error(
                            if (resp.code == 400 || resp.code == 403) "Gemini rejected the key. Check it in Settings."
                            else "Gemini is busy right now (${resp.code}). Try again."
                        )
                    }
                    val text = JSONObject(raw).optJSONArray("candidates")
                        ?.optJSONObject(0)?.optJSONObject("content")
                        ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty().trim()
                    if (text.isEmpty()) ChatReplyResult.Error("Gemini sent an empty or blocked reply.")
                    else ChatReplyResult.Success(text)
                }
            } catch (e: IOException) {
                ChatReplyResult.Error("Couldn't reach Gemini. Check your internet.")
            } catch (e: Exception) {
                ChatReplyResult.Error("Something went wrong. Try again.")
            }
        }
    }
}

object ChatPromptBuilder {
    fun build(personality: Personality, language: LanguagePreference, assistantName: String): String {
        val base = "You are $assistantName, a personal AI assistant on the user's phone. " +
            "This is typed chat, so never mention tapping, listening or speaking. Keep answers clear and not too long."
        val lang = when (language) {
            LanguagePreference.AUTO -> "Language: match the user's language (Hindi, Hinglish or English) and never translate what they wrote."
            LanguagePreference.HINDI -> "Language: always reply in Hindi."
            LanguagePreference.HINGLISH -> "Language: always reply in Hinglish."
            LanguagePreference.ENGLISH -> "Language: always reply in English."
        }
        val safety = "Safety: never claim to be human. No explicit content. Stop a topic when asked."
        return listOf(base, personality.systemInstruction, lang, safety).joinToString("\n\n")
    }
}
