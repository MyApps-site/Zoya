package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Builds one Gemini function declaration. All params are type STRING. */
fun functionDecl(
    name: String,
    description: String,
    params: Map<String, String> = emptyMap(),
    required: List<String> = emptyList(),
): JSONObject {
    val props = JSONObject()
    params.forEach { (k, v) -> props.put(k, JSONObject().put("type", "STRING").put("description", v)) }
    val schema = JSONObject().put("type", "OBJECT").put("properties", props)
    if (required.isNotEmpty()) schema.put("required", JSONArray(required))
    val decl = JSONObject().put("name", name).put("description", description)
    if (params.isNotEmpty()) decl.put("parameters", schema)
    return decl
}

object InstalledAppLabelCache {
    private const val TTL_MS = 15 * 60 * 1000L
    private val mutex = Mutex()
    private val scope = CoroutineScope(Dispatchers.IO)
    @Volatile private var map: Map<String, String> = emptyMap()
    @Volatile private var builtAt = 0L

    fun prewarm(ctx: Context) {
        val app = ctx.applicationContext
        scope.launch { get(app) }
    }

    suspend fun get(ctx: Context): Map<String, String> = mutex.withLock {
        val now = System.currentTimeMillis()
        if (map.isNotEmpty() && now - builtAt < TTL_MS) return map
        val built = withContext(Dispatchers.IO) {
            val pm = ctx.applicationContext.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val out = HashMap<String, String>()
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val label = ri.loadLabel(pm)?.toString()?.trim()?.lowercase().orEmpty()
                if (label.isNotEmpty()) out.putIfAbsent(label, ri.activityInfo.packageName)
            }
            out
        }
        map = built
        builtAt = now
        built
    }
}

object AppLauncher {
    /** Pure matching so it can be unit tested. Returns the best label or null. */
    fun matchLabel(query: String, labels: Collection<String>): String? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        labels.firstOrNull { it == q }?.let { return it }
        val qWords = q.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val candidates = labels.filter { key ->
            if (key.length < 3) return@filter false
            val kWords = key.split(Regex("\\s+")).filter { it.isNotEmpty() }
            key.startsWith(q) || q.startsWith(key) ||
                qWords.all { qw -> kWords.any { kw -> kw.startsWith(qw) } }
        }
        return candidates.minByOrNull { kotlin.math.abs(it.length - q.length) }
    }

    suspend fun findApp(ctx: Context, query: String): String? {
        val labels = InstalledAppLabelCache.get(ctx)
        val label = matchLabel(query, labels.keys) ?: return null
        return labels[label]
    }

    fun launch(ctx: Context, packageName: String): Boolean {
        return try {
            val intent = ctx.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (_: android.content.ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
}

sealed class ContactResult {
    data class Found(val name: String, val number: String) : ContactResult()
    object NoPermission : ContactResult()
    object NotFound : ContactResult()
}

object ContactResolver {
    fun looksLikeNumber(q: String): Boolean {
        val t = q.trim()
        return t.isNotEmpty() && t.all { it.isDigit() || it in " +-()." } && t.count { it.isDigit() } >= 5
    }

    /** exact (0) > prefix (1) > contains (2) */
    fun rank(query: String, name: String): Int {
        val q = query.trim().lowercase()
        val n = name.trim().lowercase()
        return when {
            n == q -> 0
            n.startsWith(q) -> 1
            else -> 2
        }
    }

    suspend fun lookup(ctx: Context, query: String): ContactResult = withContext(Dispatchers.IO) {
        if (looksLikeNumber(query)) return@withContext ContactResult.Found(query.trim(), query.trim())
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return@withContext ContactResult.NoPermission

        val found = ArrayList<Pair<String, String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${query.trim()}%"),
            null,
        )?.use { c ->
            while (c.moveToNext() && found.size < 5) {
                found += c.getString(0).orEmpty() to c.getString(1).orEmpty()
            }
        }
        val best = found.minByOrNull { rank(query, it.first) }
        if (best == null) ContactResult.NotFound else ContactResult.Found(best.first, best.second)
    }
}

object CommIntents {
    fun digits(number: String): String = number.filter { it.isDigit() }

    fun dial(number: String): Intent =
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun call(number: String): Intent =
        Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun sms(number: String, body: String): Intent =
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens the WhatsApp chat with the text typed in. The user taps Send. */
    fun whatsApp(ctx: Context, number: String, body: String): Intent {
        val url = "https://wa.me/${digits(number)}?text=${URLEncoder.encode(body, "UTF-8")}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pm = ctx.packageManager
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                pm.getPackageInfo(pkg, 0)
                intent.setPackage(pkg)
                break
            } catch (_: PackageManager.NameNotFoundException) {
            }
        }
        return intent
    }
}
