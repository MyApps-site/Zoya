package com.Lia.assistant.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.voice.NovaOrbState
import com.Lia.assistant.voice.VoiceForegroundService
import com.Lia.assistant.voice.VoiceSessionManager

private fun hasMic(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun VoiceScreen() {
    val ctx = LocalContext.current
    val state by VoiceSessionManager.state.collectAsStateWithLifecycle()
    val amp by VoiceSessionManager.amplitude.collectAsStateWithLifecycle()
    val status by VoiceSessionManager.statusText.collectAsStateWithLifecycle()
    val active by VoiceSessionManager.isActive.collectAsStateWithLifecycle()
    val muted by VoiceSessionManager.muted.collectAsStateWithLifecycle()
    val transcript by VoiceSessionManager.transcript.collectAsStateWithLifecycle()
    val hasKey = ApiKeyStore.hasKey(ctx)

    fun begin() {
        ContextCompat.startForegroundService(ctx, VoiceForegroundService.startIntent(ctx))
    }

    val askPermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true || hasMic(ctx)) begin()
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Orb(state, amp)
        Text(
            status,
            color = LiaColors.Text,
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 24.dp),
        )
        if (transcript.isNotBlank()) {
            Text(
                transcript,
                color = LiaColors.TextSecondary,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        if (!hasKey) {
            Text(
                "Pehle Settings me Gemini key daalo.",
                color = LiaColors.Error,
                modifier = Modifier.padding(top = 16.dp),
            )
        }
        Row(Modifier.padding(top = 32.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!active) {
                Button(
                    onClick = {
                        val perms = buildList {
                            add(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                        }.toTypedArray()
                        if (hasMic(ctx)) {
                            if (Build.VERSION.SDK_INT >= 33 &&
                                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                                != PackageManager.PERMISSION_GRANTED
                            ) askPermissions.launch(perms) else begin()
                        } else askPermissions.launch(perms)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LiaColors.Accent, contentColor = LiaColors.OnAccent),
                    modifier = Modifier.height(52.dp),
                ) { Text("Start", fontSize = 17.sp) }
            } else {
                OutlinedButton(onClick = { VoiceSessionManager.toggleMute() }, modifier = Modifier.height(52.dp)) {
                    Text(if (muted) "Unmute" else "Mute", color = LiaColors.Text)
                }
                Button(
                    onClick = { ctx.startService(VoiceForegroundService.stopIntent(ctx)) },
                    colors = ButtonDefaults.buttonColors(containerColor = LiaColors.Error, contentColor = LiaColors.OnAccent),
                    modifier = Modifier.height(52.dp),
                ) { Text("Stop", fontSize = 17.sp) }
            }
        }
    }
}

@Composable
private fun Orb(state: NovaOrbState, amplitude: Float) {
    val t = rememberInfiniteTransition(label = "orb")
    val breathe by t.animateFloat(
        0.96f, 1.04f,
        infiniteRepeatable(tween(2100), RepeatMode.Reverse), label = "breathe",
    )
    val core = when (state) {
        NovaOrbState.IDLE -> LiaColors.Lotus
        NovaOrbState.LISTENING -> LiaColors.Lagoon
        NovaOrbState.THINKING -> Color(0xFF8B5CF6)
        NovaOrbState.SPEAKING -> LiaColors.Accent
        NovaOrbState.CONNECTING -> Color(0xFFFFC857)
        NovaOrbState.ERROR -> LiaColors.Error
    }
    val scale = breathe + amplitude.coerceIn(0f, 1f) * 0.5f
    Canvas(
        Modifier.size(240.dp).semantics { contentDescription = "Lia status: ${state.name.lowercase()}" }
    ) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2 * 0.62f * scale
        drawCircle(
            Brush.radialGradient(listOf(core.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r * 1.9f),
            radius = r * 1.9f, center = c,
        )
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.9f), core, core.copy(alpha = 0.6f)),
                center = Offset(c.x - r * 0.3f, c.y - r * 0.3f), radius = r * 1.3f,
            ),
            radius = r, center = c,
        )
    }
}
