package com.Lia.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.PersonalityRepository
import com.Lia.assistant.voice.ChatPromptBuilder
import com.Lia.assistant.voice.ChatReplyResult
import com.Lia.assistant.voice.ChatTurn
import com.Lia.assistant.voice.GeminiTextClient
import kotlinx.coroutines.launch

private data class Bubble(val text: String, val isUser: Boolean, val isError: Boolean = false)

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bubbles = remember { mutableStateListOf<Bubble>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(bubbles.size) {
        if (bubbles.isNotEmpty()) listState.animateScrollToItem(bubbles.lastIndex)
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        bubbles += Bubble(text, true)
        busy = true
        scope.launch {
            val personality = PersonalityRepository.getPersonality(ctx)
            val language = PersonalityRepository.getLanguage(ctx)
            val name = PersonalityRepository.getAssistantName(ctx)
            val history = bubbles.filter { !it.isError }.map { ChatTurn(it.isUser, it.text) }
            when (val r = GeminiTextClient.reply(
                ApiKeyStore.getKey(ctx), ChatPromptBuilder.build(personality, language, name), history
            )) {
                is ChatReplyResult.Success -> bubbles += Bubble(r.text, false)
                is ChatReplyResult.Error -> bubbles += Bubble(r.message, false, isError = true)
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        if (bubbles.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Kuch bhi poochho. Hindi, Hinglish ya English.", color = LiaColors.TextSecondary)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(bubbles) { b ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (b.isUser) Arrangement.End else Arrangement.Start) {
                        Text(
                            b.text,
                            color = if (b.isUser) LiaColors.OnAccent else if (b.isError) LiaColors.Error else LiaColors.Text,
                            modifier = Modifier
                                .background(
                                    if (b.isUser) LiaColors.Accent else LiaColors.Surface,
                                    RoundedCornerShape(18.dp),
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .fillMaxWidth(0.85f),
                        )
                    }
                }
                if (busy) item { Text("Soch rahi hun…", color = LiaColors.TextSecondary) }
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Yahan likho…") },
                modifier = Modifier.weight(1f),
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = LiaColors.Text,
                    unfocusedTextColor = LiaColors.Text,
                    focusedBorderColor = LiaColors.Accent,
                    unfocusedBorderColor = LiaColors.Raised,
                    cursorColor = LiaColors.Accent,
                ),
            )
            Button(
                onClick = { send() },
                enabled = !busy && input.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = LiaColors.Accent, contentColor = LiaColors.OnAccent),
            ) { Text("Send") }
        }
    }
}
