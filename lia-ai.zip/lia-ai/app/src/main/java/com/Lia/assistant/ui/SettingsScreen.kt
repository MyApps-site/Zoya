package com.Lia.assistant.ui

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.Lia.assistant.action.FlavorInfo
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import com.Lia.assistant.data.PersonalityRepository
import kotlinx.coroutines.launch

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = LiaColors.Text,
    unfocusedTextColor = LiaColors.Text,
    focusedBorderColor = LiaColors.Accent,
    unfocusedBorderColor = LiaColors.Raised,
    cursorColor = LiaColors.Accent,
    focusedLabelColor = LiaColors.Accent,
    unfocusedLabelColor = LiaColors.TextSecondary,
)

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = LiaColors.Accent, fontSize = 15.sp)
        content()
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val personality by PersonalityRepository.personality(ctx).collectAsStateWithLifecycle(Personality.NORMAL)
    val language by PersonalityRepository.language(ctx).collectAsStateWithLifecycle(LanguagePreference.AUTO)
    val savedName by PersonalityRepository.assistantName(ctx).collectAsStateWithLifecycle("Lia")

    var key by remember { mutableStateOf(ApiKeyStore.getKey(ctx)) }
    var keySaved by remember { mutableStateOf(false) }
    var name by remember(savedName) { mutableStateOf(savedName) }

    val askContacts = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Section("Gemini key") {
            Text(
                "aistudio.google.com se free key banao aur yahan paste karo. Ye sirf is phone me rehti hai.",
                color = LiaColors.TextSecondary, fontSize = 14.sp,
            )
            OutlinedTextField(
                value = key,
                onValueChange = { key = it; keySaved = false },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors(),
            )
            Button(
                onClick = { ApiKeyStore.saveKey(ctx, key); keySaved = true },
                colors = ButtonDefaults.buttonColors(containerColor = LiaColors.Accent, contentColor = LiaColors.OnAccent),
            ) { Text(if (keySaved) "Saved" else "Save key") }
        }

        Section("Assistant ka naam") {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors(),
            )
            OutlinedButton(onClick = { scope.launch { PersonalityRepository.setAssistantName(ctx, name) } }) {
                Text("Naam badlo", color = LiaColors.Text)
            }
        }

        Section("Personality") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Personality.entries.forEach { p ->
                    FilterChip(
                        selected = p == personality,
                        onClick = { scope.launch { PersonalityRepository.setPersonality(ctx, p) } },
                        label = { Text("${p.icon} ${p.displayName}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LiaColors.Accent,
                            selectedLabelColor = LiaColors.OnAccent,
                            labelColor = LiaColors.Text,
                        ),
                    )
                }
            }
            Text(personality.description, color = LiaColors.TextSecondary, fontSize = 14.sp)
        }

        Section("Bhasha") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LanguagePreference.entries.forEach { l ->
                    FilterChip(
                        selected = l == language,
                        onClick = { scope.launch { PersonalityRepository.setLanguage(ctx, l) } },
                        label = { Text(l.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = LiaColors.Accent,
                            selectedLabelColor = LiaColors.OnAccent,
                            labelColor = LiaColors.Text,
                        ),
                    )
                }
            }
        }

        Section("Phone ke kaam") {
            Text("Contacts aur call ki ijazat do, tab Lia naam se call/message kar paegi.", color = LiaColors.TextSecondary, fontSize = 14.sp)
            OutlinedButton(onClick = {
                askContacts.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
            }) { Text("Ijazat do", color = LiaColors.Text) }

            if (FlavorInfo.screenControlAvailable) {
                val enabled = FlavorInfo.screenControlEnabled(ctx)
                Text(
                    if (enabled) "Screen control: chalu" else "Screen control: band. Accessibility settings me Lia AI ko chalu karo.",
                    color = if (enabled) LiaColors.Lagoon else LiaColors.TextSecondary, fontSize = 14.sp,
                )
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Accessibility settings kholo", color = LiaColors.Text) }
            }
        }
    }
}
