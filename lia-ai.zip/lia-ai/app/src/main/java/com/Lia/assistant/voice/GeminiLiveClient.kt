package com.Lia.assistant.voice

import android.util.Base64
import com.Lia.assistant.action.LiaToolCatalog
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Skips a tool call id that was already handled. Bounded so it never grows without limit. */
class ToolCallDeduplicator(private val limit: Int = 64) {
    private val seen = LinkedHashSet<String>()

    @Synchronized
    fun firstTime(id: String): Boolean {
        if (id.isEmpty()) return true
        if (!seen.add(id)) return false
        while (seen.size > limit) {
            val it = seen.iterator()
            it.next()
            it.remove()
        }
        return true
    }
}

class GeminiLiveClient(private val apiKey: String) {

    interface Listener {
        fun onSetupComplete()
        fun onAudioChunk(bytes: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTurnComplete()
        fun onInterrupted()
        fun onError(message: String)
        fun onClosed()
    }

    companion object {
        /** Keep the model name in ONE place. Check the Live API docs if connecting fails. */
        const val MODEL = "models/gemini-3.1-flash-live-preview"
        private const val WS_BASE =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val dedup = ToolCallDeduplicator()
    @Volatile private var socket: WebSocket? = null
    @Volatile private var ready = false

    fun connect(systemInstruction: String, voiceName: String = "Aoede", listener: Listener) {
        val request = Request.Builder().url("$WS_BASE?key=$apiKey").build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetup(systemInstruction, voiceName).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handle(text, listener)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8(), listener)

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                // Never include the URL (it holds the key) or raw server data.
                listener.onError("Connection problem (${response?.code ?: "network"})")
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                listener.onClosed()
            }
        })
    }

    private fun buildSetup(systemInstruction: String, voiceName: String): JSONObject {
        val setup = JSONObject()
            .put("model", MODEL)
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName)
                            )
                        )
                    )
            )
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        val decls = LiaToolCatalog.declarations()
        if (decls.length() > 0) {
            setup.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
        }
        return JSONObject().put("setup", setup)
    }

    private fun handle(raw: String, l: Listener) {
        val msg = try { JSONObject(raw) } catch (_: Exception) { return }

        if (msg.has("setupComplete")) {
            ready = true
            l.onSetupComplete()
        }

        msg.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.optJSONObject(i) ?: continue
                val id = c.optString("id")
                if (!dedup.firstTime(id)) continue
                l.onToolCall(id, c.optString("name"), c.optJSONObject("args") ?: JSONObject())
            }
        }

        val sc = msg.optJSONObject("serverContent") ?: return
        sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val mime = inline.optString("mimeType")
                if (mime.startsWith("audio/pcm")) {
                    val data = inline.optString("data")
                    if (data.isNotEmpty()) l.onAudioChunk(Base64.decode(data, Base64.DEFAULT))
                }
            }
        }
        sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
            ?.let { l.onInputTranscript(it) }
        sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }
            ?.let { l.onOutputTranscript(it) }
        if (sc.optBoolean("interrupted", false)) l.onInterrupted()
        if (sc.optBoolean("turnComplete", false)) l.onTurnComplete()
    }

    fun sendAudio(pcm: ByteArray) {
        val ws = socket ?: return
        if (!ready) return
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        val json = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("mimeType", "audio/pcm;rate=16000")
                    .put("data", b64)
            )
        )
        ws.send(json.toString())
    }

    fun sendToolResponse(id: String, name: String, result: JSONObject) {
        val ws = socket ?: return
        val json = JSONObject().put(
            "toolResponse", JSONObject().put(
                "functionResponses", JSONArray().put(
                    JSONObject().put("id", id).put("name", name).put("response", result)
                )
            )
        )
        ws.send(json.toString())
    }

    fun disconnect() {
        ready = false
        try { socket?.close(1000, null) } catch (_: Exception) {}
        socket = null
    }
}
