package com.Lia.assistant.action

import android.content.Context

/** Play flavor: no screen control. */
object FlavorInfo {
    const val screenControlAvailable = false
    @Suppress("UNUSED_PARAMETER")
    fun screenControlEnabled(ctx: Context): Boolean = false
}
