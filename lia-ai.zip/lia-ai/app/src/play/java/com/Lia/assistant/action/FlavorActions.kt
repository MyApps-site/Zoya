package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/** Play flavor: open_app, call_contact, message_contact only. */
object LiaToolCatalog {
    fun declarations(): JSONArray = JSONArray()
        .put(functionDecl("open_app", "Open an installed app by its name.", mapOf("app_name" to "Name of the app"), listOf("app_name")))
        .put(functionDecl("call_contact", "Call a contact by name or a phone number.", mapOf("contact" to "Contact name or phone number"), listOf("contact")))
        .put(
            functionDecl(
                "message_contact",
                "Prepare a message to a contact. This only opens the message screen; the user taps Send.",
                mapOf(
                    "contact" to "Contact name or phone number",
                    "message" to "The message text",
                    "app" to "sms or whatsapp (default sms)",
                ),
                listOf("contact", "message"),
            )
        )
}

object LiaCapabilityPrompts {
    fun toolInstruction(name: String): String =
        "Phone abilities: you can open apps, call a contact, and prepare a message (the user taps Send). " +
            "You cannot read or control the screen and you cannot post to social apps; say so plainly if asked. " +
            "Use a tool only when the user clearly asks for that action, then confirm in one short sentence."
}

object ActionExecutor {
    suspend fun execute(ctx: Context, name: String, args: JSONObject): JSONObject = when (name) {
        "open_app" -> openApp(ctx, args.optString("app_name"))
        "call_contact" -> callContact(ctx, args.optString("contact"))
        "message_contact" -> messageContact(ctx, args.optString("contact"), args.optString("message"), args.optString("app"))
        else -> JSONObject().put("error", "Unknown tool: $name")
    }

    private suspend fun openApp(ctx: Context, appName: String): JSONObject {
        val pkg = AppLauncher.findApp(ctx, appName) ?: return JSONObject().put("result", "app_not_found")
        return JSONObject().put("result", if (AppLauncher.launch(ctx, pkg)) "opened" else "could_not_open")
    }

    private suspend fun callContact(ctx: Context, contact: String): JSONObject =
        when (val r = ContactResolver.lookup(ctx, contact)) {
            is ContactResult.NoPermission -> JSONObject().put("result", "contacts_permission_needed")
            is ContactResult.NotFound -> JSONObject().put("result", "contact_not_found")
            is ContactResult.Found -> {
                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
                    PackageManager.PERMISSION_GRANTED
                try {
                    ctx.startActivity(if (granted) CommIntents.call(r.number) else CommIntents.dial(r.number))
                    JSONObject().put("result", if (granted) "calling" else "dialer_opened_no_permission").put("contact", r.name)
                } catch (e: Exception) {
                    JSONObject().put("result", "failed")
                }
            }
        }

    private suspend fun messageContact(ctx: Context, contact: String, message: String, app: String): JSONObject =
        when (val r = ContactResolver.lookup(ctx, contact)) {
            is ContactResult.NoPermission -> JSONObject().put("result", "contacts_permission_needed")
            is ContactResult.NotFound -> JSONObject().put("result", "contact_not_found")
            is ContactResult.Found -> try {
                val intent = if (app.equals("whatsapp", true)) CommIntents.whatsApp(ctx, r.number, message)
                else CommIntents.sms(r.number, message)
                ctx.startActivity(intent)
                JSONObject().put("result", "composer_opened").put("contact", r.name)
            } catch (e: Exception) {
                JSONObject().put("result", "failed")
            }
        }
}
