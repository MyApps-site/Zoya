package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Direct flavor: the Play tools plus screen control through the AccessibilityService. */
object LiaToolCatalog {
    fun declarations(): JSONArray = JSONArray()
        .put(functionDecl("open_app", "Open an installed app by its name.", mapOf("app_name" to "Name of the app"), listOf("app_name")))
        .put(functionDecl("call_contact", "Call a contact by name or a phone number.", mapOf("contact" to "Contact name or phone number"), listOf("contact")))
        .put(
            functionDecl(
                "message_contact",
                "Send a message to a contact by SMS or WhatsApp.",
                mapOf(
                    "contact" to "Contact name or phone number",
                    "message" to "The message text",
                    "app" to "sms or whatsapp (default sms)",
                ),
                listOf("contact", "message"),
            )
        )
        .put(functionDecl("read_screen", "Read the visible text on the phone screen."))
        .put(functionDecl("tap_text", "Tap the button or item showing this text.", mapOf("text" to "Visible text to tap"), listOf("text")))
        .put(functionDecl("type_text", "Type text into the focused input field.", mapOf("text" to "Text to type"), listOf("text")))
        .put(functionDecl("scroll_screen", "Scroll the current screen.", mapOf("direction" to "down or up"), listOf("direction")))
        .put(functionDecl("go_back", "Press the Back button."))
        .put(functionDecl("go_home", "Go to the home screen."))
}

object LiaCapabilityPrompts {
    fun toolInstruction(name: String): String =
        "Phone abilities: open apps, call a contact, message a contact, and control the screen " +
            "(read_screen, tap_text, type_text, scroll_screen, go_back, go_home). " +
            "For screen tasks, call read_screen first to see what is there, then act step by step. " +
            "Before anything that cannot be undone (sending, posting, paying, deleting), ask the user to confirm out loud. " +
            "Never enter passwords or one-time codes. Use a tool only when the user clearly asks."
}

object ActionExecutor {
    suspend fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        return when (name) {
            "open_app" -> openApp(ctx, args.optString("app_name"))
            "call_contact" -> callContact(ctx, args.optString("contact"))
            "message_contact" -> messageContact(ctx, args.optString("contact"), args.optString("message"), args.optString("app"))
            "read_screen", "tap_text", "type_text", "scroll_screen", "go_back", "go_home" -> screen(ctx, name, args)
            else -> JSONObject().put("error", "Unknown tool: $name")
        }
    }

    private fun screen(ctx: Context, name: String, args: JSONObject): JSONObject {
        val svc = NovaAccessibilityService.instance
        if (!NovaAccessibilityService.isEnabled(ctx) || svc == null) {
            return JSONObject().put("result", "accessibility_not_enabled")
        }
        return when (name) {
            "read_screen" -> JSONObject().put("result", "screen").put("screen", svc.readScreen())
            "tap_text" -> JSONObject().put("result", if (svc.tapText(args.optString("text"))) "tapped" else "element_not_found")
            "type_text" -> JSONObject().put("result", if (svc.typeText(args.optString("text"))) "typed" else "no_focused_field")
            "scroll_screen" -> JSONObject().put(
                "result", if (svc.scroll(!args.optString("direction").equals("up", true))) "scrolled" else "nothing_scrollable"
            )
            "go_back" -> JSONObject().put("result", if (svc.back()) "done" else "failed")
            else -> JSONObject().put("result", if (svc.home()) "done" else "failed")
        }
    }

    private suspend fun openApp(ctx: Context, appName: String): JSONObject {
        val pkg = AppLauncher.findApp(ctx, appName) ?: return JSONObject().put("result", "app_not_found")
        return JSONObject().put("result", if (AppLauncher.launch(ctx, pkg)) "opened" else "could_not_open")
    }

    private suspend fun callContact(ctx: Context, contact: String): JSONObject =
        when (val r = ContactResolver.lookup(ctx, contact)) {
            is ContactResult.NoPermission -> JSONObject().put("result", "contacts_permission_needed")
            is ContactResult.NotFound -> JSONObject().put("result", "contact_not_found")
            is ContactResult.Found -> {
                val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
                    PackageManager.PERMISSION_GRANTED
                try {
                    ctx.startActivity(if (granted) CommIntents.call(r.number) else CommIntents.dial(r.number))
                    JSONObject().put("result", if (granted) "calling" else "dialer_opened_no_permission").put("contact", r.name)
                } catch (e: Exception) {
                    JSONObject().put("result", "failed")
                }
            }
        }

    private suspend fun messageContact(ctx: Context, contact: String, message: String, app: String): JSONObject =
        when (val r = ContactResolver.lookup(ctx, contact)) {
            is ContactResult.NoPermission -> JSONObject().put("result", "contacts_permission_needed")
            is ContactResult.NotFound -> JSONObject().put("result", "contact_not_found")
            is ContactResult.Found -> try {
                val whatsapp = app.equals("whatsapp", true)
                ctx.startActivity(if (whatsapp) CommIntents.whatsApp(ctx, r.number, message) else CommIntents.sms(r.number, message))
                val sent = autoTapSend(ctx, whatsapp)
                JSONObject().put("result", if (sent) "sent" else "composer_opened_send_not_found").put("contact", r.name)
            } catch (e: Exception) {
                JSONObject().put("result", "failed")
            }
        }

    /** Up to 12 tries, 400 ms apart. Needs the accessibility service. */
    private suspend fun autoTapSend(ctx: Context, whatsapp: Boolean): Boolean {
        if (!NovaAccessibilityService.isEnabled(ctx)) return false
        repeat(12) {
            delay(400)
            val svc = NovaAccessibilityService.instance ?: return false
            if (whatsapp) svc.tapText("Continue to chat")
            if (svc.tapText("Send")) return true
        }
        return false
    }
}

/** Used by the Settings screen. */
object FlavorInfo {
    const val screenControlAvailable = true
    fun screenControlEnabled(ctx: Context): Boolean = NovaAccessibilityService.isEnabled(ctx)
}
