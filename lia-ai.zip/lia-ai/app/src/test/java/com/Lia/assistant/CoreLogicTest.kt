package com.Lia.assistant

import com.Lia.assistant.action.AppLauncher
import com.Lia.assistant.action.ContactResolver
import com.Lia.assistant.voice.ConversationMemory
import com.Lia.assistant.voice.DetectedLanguage
import com.Lia.assistant.voice.LanguageDetector
import com.Lia.assistant.voice.LiveAudioIO
import com.Lia.assistant.voice.ToolCallDeduplicator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreLogicTest {

    @Test fun detectsDevanagariAsHindi() {
        assertEquals(DetectedLanguage.HINDI, LanguageDetector.detect("आज मौसम कैसा है"))
    }

    @Test fun detectsHinglish() {
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("kya haal hai yaar"))
    }

    @Test fun detectsEnglishAndBlank() {
        assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("what's the weather"))
        assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect("   "))
    }

    @Test fun memoryKeepsLastTwelveTurns() {
        val m = ConversationMemory()
        repeat(20) { m.add(ConversationMemory.Role.USER, "msg $it") }
        val recap = m.recap()!!
        assertFalse(recap.contains("msg 0"))
        assertTrue(recap.contains("msg 19"))
        m.clear()
        assertNull(m.recap())
    }

    @Test fun dedupSkipsSeenIds() {
        val d = ToolCallDeduplicator()
        assertTrue(d.firstTime("a"))
        assertFalse(d.firstTime("a"))
        assertTrue(d.firstTime("b"))
    }

    @Test fun appMatchingPrefersExactThenPrefix() {
        val labels = listOf("youtube", "youtube music", "whatsapp", "maps")
        assertEquals("youtube", AppLauncher.matchLabel("youtube", labels))
        assertEquals("whatsapp", AppLauncher.matchLabel("whats", labels))
        assertNull(AppLauncher.matchLabel("tube", labels))
    }

    @Test fun contactNumberAndRanking() {
        assertTrue(ContactResolver.looksLikeNumber("+91 98765 43210"))
        assertFalse(ContactResolver.looksLikeNumber("Rahul"))
        assertEquals(0, ContactResolver.rank("rahul", "Rahul"))
        assertEquals(1, ContactResolver.rank("rah", "Rahul"))
        assertEquals(2, ContactResolver.rank("ahu", "Rahul"))
    }

    @Test fun rmsOfSilenceIsZeroAndLoudIsHigh() {
        assertEquals(0f, LiveAudioIO.rms(ByteArray(100)), 0.0001f)
        val loud = ByteArray(100) { if (it % 2 == 1) 0x7F else 0xFF.toByte() }
        assertTrue(LiveAudioIO.rms(loud) > 0.9f)
        assertNotNull(loud)
    }
}
